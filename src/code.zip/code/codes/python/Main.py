print('Hello World')
n=int(input())
print(n)