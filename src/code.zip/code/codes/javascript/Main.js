while(true)
{
    console.log('Hello World')
}