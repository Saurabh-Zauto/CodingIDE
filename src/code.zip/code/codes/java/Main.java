import java.util.*;
public class Main
{
  public static void main(String[] args) {
    System.out.println("Hello World");
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    System.out.println(n);
  }
}
    